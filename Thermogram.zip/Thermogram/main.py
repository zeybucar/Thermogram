import PIL
import cv2
import numpy as np
from PIL import Image
import pandas as pd
import openpyxl
import xlwt
from xlwt import Workbook

scale_array = {}
tbl = {}

# img = cv2.imread('skala.jpg')
skala = ("skala1.jpg")
dosya = ("black_body.jpg")
img = PIL.Image.open(skala)
img2 = PIL.Image.open(dosya)

for x in range(0, 6):
    t = 96.96 + 0.1
    for y in range(0, 670):
        t -= 0.1
        tt = round(t, 2)
        rgb_tuple = img.getpixel((x, y))
        # print(rgb_tuple)
        r = rgb_tuple[0]
        g = rgb_tuple[1]
        b = rgb_tuple[2]
        scale_array[r, g, b] = tt
        # print(x,y,rgb_tuple, tt)

        # print(scale_array[4,3,9])

# for x in scale_array:
# rint(x[0])



metin=""
sayac=0
wer=0
bulundu=0
tablo=''
wb = Workbook()
sheet1 = wb.add_sheet('Sheet 1')
sheet1.write(0, 0, "Pixel y")
for z in range(1, 745):
    tablo=""
    for q in range(0, 912):

        rgb_tuple1 = img2.getpixel((q, z))
        r1 = rgb_tuple1[0]
        g1 = rgb_tuple1[1]
        b1 = rgb_tuple1[2]
        #print(q,(r1,g1,b1))
        bulundu = 0

        if (rgb_tuple1 in scale_array):
            derece = (scale_array[r1, g1, b1])
            #print(q, (r1, g1, b1), derece, 'olan')
            tablo=tablo + str(derece)+', '

        else:
            rx1 = r1 - 10
            rx2 = r1 + 10
            gx1 = g1 - 10
            gx2 = g1 + 10
            bx1 = b1 - 10
            bx2 = b1 + 10
            for Ar in range(rx1, rx2):
                for Ag in range(gx1, gx2):
                    for Ab in range(bx1, bx2):
                        if ((Ar, Ag, Ab) in scale_array) and bulundu==0:
                            bulundu=1
                            derece1 = (scale_array[Ar, Ag, Ab])
                            scale_array[Ar,Ag,Ab] = derece1
                            wer=wer+1
                            #print(wer,q, (Ar, Ag, Ab),derece1, 'yakın bulundu')
                            tablo=tablo + str(derece1)+', '

            if ((Ar, Ag, Ab) not in scale_array) and bulundu == 0:
                #print(wer,q, (Ar, Ag, Ab),derece1, 'YOKYOkYOK')
                tablo=tablo+"?, "


    print(tablo)

    sheet1.write(z, 0, z)
    sheet1.write(z, 1, tablo)
wb.save('xlwt saa.xls')


